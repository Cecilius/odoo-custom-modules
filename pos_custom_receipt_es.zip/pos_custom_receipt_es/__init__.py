# pos_custom_receipt_es/__init__.py
# Empty on purpose: this module only provides QWeb templates